create function trunc(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function trunc(macaddr8) is 'value truncated to ''scale'' of zero';

alter function trunc(macaddr8) owner to rdsadmin;

