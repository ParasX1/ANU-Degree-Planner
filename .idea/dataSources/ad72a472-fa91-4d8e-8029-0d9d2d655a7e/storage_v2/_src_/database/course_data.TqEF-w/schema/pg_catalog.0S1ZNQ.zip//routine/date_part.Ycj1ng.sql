create function date_part(text, date) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$
begin
-- missing source code
end;
$$;

comment on function date_part(text, timestamp with time zone) is 'extract field from date';

alter function date_part(text, timestamp with time zone) owner to rdsadmin;

