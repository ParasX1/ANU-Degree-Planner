create function quote_nullable(anyelement) returns text
    stable
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.quote_nullable($1::pg_catalog.text)$$;

alter function quote_nullable(anyelement) owner to rdsadmin;

